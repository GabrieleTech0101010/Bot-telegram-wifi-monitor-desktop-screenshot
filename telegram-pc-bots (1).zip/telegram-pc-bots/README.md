# 🤖 Telegram PC Bots

Raccolta di piccoli bot Telegram in Python per monitorare e controllare un PC Windows da remoto.

## Bot disponibili

| Bot | Cosa fa |
|---|---|
| [`wifi-monitor-bot`](./wifi-monitor-bot) | Notifica su Telegram ogni volta che un nuovo dispositivo si connette alla rete WiFi |
| [`screenshot-bot`](./screenshot-bot) | Invia uno screenshot del PC su richiesta, scrivendo `/screenshot` al bot |

Ogni cartella contiene il proprio `README.md` con istruzioni complete di installazione e configurazione.

## Requisiti comuni

- Python 3.10+
- Un bot Telegram creato tramite [@BotFather](https://t.me/BotFather)
- Windows (gli script sono stati sviluppati e testati su Windows, ma sono facilmente adattabili a Linux/macOS)

## Nota sulla sicurezza

Ogni bot richiede un token Telegram personale e, dove rilevante, un Chat ID autorizzato. Questi valori vanno inseriti in un file `.env` locale (vedi `.env.example` in ciascuna cartella) che **non va mai committato** su GitHub. Il `.gitignore` del repository li esclude già di default.

## Licenza

Progetti distribuiti liberamente per uso personale ed educativo.
