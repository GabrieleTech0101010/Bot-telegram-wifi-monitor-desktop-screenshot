# 📸 PC Screenshot Bot

## Cos'è questo progetto

**PC Screenshot Bot** è un piccolo programma Python che gira in background sul tuo PC e ti permette di vedere lo schermo del tuo computer da remoto, in qualsiasi momento, semplicemente scrivendo un comando su Telegram dal telefono.

È utile in tanti scenari pratici: controllare se un download è finito mentre sei fuori casa, vedere se un programma lanciato a distanza sta funzionando, dare un'occhiata veloce al PC senza dover installare software di controllo remoto complessi (come TeamViewer o AnyDesk), che spesso sono più pesanti del necessario se ti serve solo "vedere" lo schermo una volta ogni tanto.

## Come funziona, nel dettaglio

A differenza di altri bot che si limitano a *mandare* messaggi quando succede qualcosa, questo bot deve anche **ricevere** i tuoi comandi da Telegram, quindi resta costantemente "in ascolto".

Il meccanismo tecnico si chiama **long polling**: ogni 2 secondi (tempo modificabile), lo script contatta i server di Telegram e chiede "è arrivato qualche messaggio nuovo per me?". Se la risposta è sì, lo script legge il testo del messaggio e decide cosa fare.

Quando il messaggio ricevuto è esattamente `/screenshot`, succede questo:

1. Lo script usa la libreria `pyautogui` per catturare un'istantanea di tutto ciò che è visibile sullo schermo in quel momento
2. L'immagine viene convertita in formato PNG, tenuta temporaneamente in memoria (non viene salvata come file sul disco, per non accumulare screenshot nel tempo)
3. Viene inviata immediatamente come foto nella chat Telegram da cui hai scritto il comando

**Un controllo di sicurezza importante**: lo script tiene traccia di un solo "Chat ID autorizzato" (il tuo). Se qualcun altro, per qualsiasi motivo, scoprisse lo username del tuo bot e gli scrivesse `/screenshot`, lo script lo ignorerebbe completamente, perché il suo numero di chat non corrisponde a quello autorizzato. In questo modo solo tu puoi effettivamente ricevere screenshot del tuo PC.

## Cosa ti serve prima di iniziare

- Un PC con Windows, Linux o macOS
- **Python** versione 3.10 o successiva installato
- Un account Telegram
- Il PC deve avere una **sessione desktop attiva**, cioè qualcuno deve aver fatto login: la cattura schermo non funziona se il PC gira come "servizio" invisibile senza nessun utente collegato, perché in quel caso non esiste nessuno schermo visibile da catturare

## Guida all'installazione, passo per passo

### Passo 1 — Installa le librerie Python necessarie

Apri il terminale nella cartella del progetto e scrivi:
```bash
pip install -r requirements.txt
```
Questo installa `pyautogui` (cattura schermo), `pillow` (gestione immagini) e `requests` (comunicazione con Telegram).

### Passo 2 — Crea il tuo bot Telegram personale

1. Apri Telegram e cerca l'utente **@BotFather**
2. Scrivigli `/newbot`
3. Scegli un nome (es. "Il mio Screenshot PC") e uno username univoco che finisca per "bot" (es. `MioScreenshotPC_bot`)
4. BotFather ti risponderà con un **TOKEN**, una stringa tipo:
   ```
   123456789:AAHdqTcvCH1vGWJxfSeofSAs0K5PALDsaw
   ```
   Copialo e tienilo al sicuro: equivale a una password del bot. **Non condividerlo mai con nessuno.**

> Consiglio: se hai già altri bot Telegram (es. un monitor WiFi), crea comunque **un bot separato e dedicato** per questa funzione, invece di riusare lo stesso. Tenere le funzioni divise rende tutto più chiaro e più sicuro da gestire.

### Passo 3 — Trova il tuo Chat ID

1. Cerca il bot appena creato su Telegram e scrivigli un messaggio qualsiasi (es. "ciao")
2. Apri nel browser, sostituendo `<TOKEN>` con il tuo token:
   ```
   https://api.telegram.org/bot<TOKEN>/getUpdates
   ```
3. Cerca nel testo la parte simile a:
   ```
   "chat":{"id":987654321,"first_name":"Mario",...}
   ```
   Il numero accanto a `"id"` è il tuo **Chat ID**.

Se vedi `"result":[]` (vuoto), scrivi di nuovo al bot e ricarica la pagina.

### Passo 4 — Configura lo script con i tuoi dati

Apri il file `screenshot_bot.py` con un editor di testo (anche il Blocco Note va benissimo) e trova queste righe all'inizio del file:

```python
TELEGRAM_BOT_TOKEN = ""     # token ottenuto da @BotFather
AUTHORIZED_CHAT_ID = ""     # solo questo chat_id può usare i comandi
```

Sostituisci entrambi i valori vuoti con i tuoi dati reali (il Chat ID va scritto come testo tra virgolette, anche se è composto solo da cifre), poi salva il file.

### Passo 5 — Avvia lo script e testalo

Dal terminale, nella cartella dello script:
```bash
python screenshot_bot.py
```

Se token o chat_id non sono configurati, lo script te lo segnala subito e si ferma. Se tutto è corretto, non vedrai nulla scritto a schermo: è normale, significa solo che lo script è "in ascolto" e aspetta un tuo comando.

Vai su Telegram, apri la chat con il bot, e scrivi:
```
/screenshot
```
Entro pochi secondi dovresti ricevere una foto dello schermo del tuo PC direttamente in chat.

## Avvio automatico all'accensione del PC (Windows)

Se vuoi che il bot parta da solo ogni volta che fai login, senza doverlo lanciare a mano ogni volta:

1. Apri l'**Utilità di pianificazione** di Windows
2. Clicca **"Crea attività..."**
3. Nella scheda **Generale**: dai un nome all'attività — **non spuntare** "Esegui con i privilegi più elevati" in questo caso: a differenza di altri bot che richiedono permessi da amministratore, la cattura schermo funziona solo nella sessione desktop "normale" dell'utente, e con permessi elevati spesso smette di funzionare correttamente
4. Nella scheda **Attivazione**: crea un trigger con "Inizia l'attività" impostato su **"All'accesso"**
5. Nella scheda **Azioni**: avvia `python.exe` (il percorso esatto si trova con `where python` da cmd) con `screenshot_bot.py` come argomento, e la cartella dello script come percorso di partenza
6. Nella scheda **Condizioni**: togli la spunta dal vincolo sull'alimentazione elettrica
7. Salva

## Problemi comuni

- **Non arriva nessuna risposta a `/screenshot`**: controlla il file di log `screenshot_bot_log.txt`, creato automaticamente nella stessa cartella, che registra ogni comando ricevuto ed eventuali errori
- **Lo screenshot arriva nero o vuoto**: assicurati che lo script giri nella sessione desktop attiva (non come attività con privilegi elevati, non tramite Remote Desktop disconnesso)
- **Il bot non risponde a nessuno**: verifica che il tuo Chat ID in `AUTHORIZED_CHAT_ID` corrisponda esattamente a quello che hai trovato al Passo 3

## ⚠️ Attenzione alla sicurezza prima di pubblicare il codice

Una volta configurato, questo script contiene il **token del bot scritto in chiaro** all'interno del file `.py`. Il token equivale a una password: chiunque lo ottenga può controllare il tuo bot.

**Se mantieni questo progetto su un repository pubblico (es. GitHub):**
- Non fare mai il commit del file `screenshot_bot.py` **dopo** aver inserito i tuoi dati reali
- Mantieni online solo la versione con i placeholder vuoti, come quella originale di questo repository
- Le tue modifiche personali con i dati reali vanno fatte solo in una copia locale del file, mai committata
- Se per errore un token finisce comunque online, revocalo subito parlando con @BotFather (comando `/revoke`) e generane uno nuovo
- Valuta anche di non rendere pubblico lo username del tuo bot, per ridurre ulteriormente la superficie di attacco: anche se il controllo sul Chat ID protegge dai comandi non autorizzati, meno persone conoscono il bot e meglio è

## Licenza

Questo progetto è distribuito liberamente per uso personale ed educativo.
