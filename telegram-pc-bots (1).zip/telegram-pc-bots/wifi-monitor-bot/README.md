# 📡 WiFi Monitor Bot

## Cos'è questo progetto

**WiFi Monitor Bot** è un piccolo programma Python che gira in background sul tuo PC Windows e sorveglia la tua rete WiFi domestica. Il suo unico scopo è uno: **avvisarti su Telegram ogni volta che un dispositivo che non hai mai visto prima si collega alla tua rete.**

È pensato per chi vuole un modo semplice e gratuito per sapere se qualcuno (un vicino, un ospite che si è segnato la password, o peggio un intruso) si connette alla propria rete WiFi senza che tu lo sappia. Non richiede hardware aggiuntivo, router particolari o abbonamenti: basta il PC che probabilmente hai già acceso in casa.

## Come funziona, nel dettaglio

Il cuore del programma è una libreria chiamata **Nmap**, uno strumento molto diffuso nel mondo della sicurezza informatica per "esplorare" le reti. Lo script lo usa per fare quella che si chiama una **scansione ARP**: in pratica manda un piccolo segnale a tutti gli indirizzi possibili della tua rete locale (es. da 192.168.1.1 a 192.168.1.254) e registra chi risponde.

Ogni dispositivo in rete (telefono, PC, smart TV, stampante, ecc.) ha un numero identificativo univoco chiamato **indirizzo MAC**, che non cambia mai (a differenza dell'indirizzo IP, che il router può riassegnare di tanto in tanto). Lo script usa proprio il MAC per riconoscere se un dispositivo è "vecchio" o "nuovo".

Il ciclo di funzionamento è questo:

1. **Scansione**: ogni 60 secondi (tempo modificabile) lo script chiede a Nmap l'elenco di tutti i dispositivi attualmente collegati
2. **Confronto**: per ogni dispositivo trovato, controlla se il suo indirizzo MAC è già presente in un file chiamato `known_devices.json`, che funge da "memoria" di tutti i dispositivi già visti in passato
3. **Notifica**: se un MAC non è nell'elenco, significa che è la prima volta che lo script lo vede. Lo aggiunge subito al file `known_devices.json` (così non ti avviserà più per lui) e ti manda un messaggio Telegram con tutte le informazioni raccolte: indirizzo IP, MAC, nome del dispositivo (se disponibile), produttore (es. Apple, Samsung, TP-Link) e un pulsante per aprire al volo la pagina di amministrazione del router, utile se vuoi bloccare subito quel dispositivo

Il file `known_devices.json` resta salvato sul disco e sopravvive ai riavvii, quindi la prima volta che lo avvii ti segnalerà **tutti** i dispositivi attualmente connessi (perché per lo script sono tutti "nuovi", non avendoli mai visti), ma dalle esecuzioni successive riceverai notifiche solo per i dispositivi davvero inediti.

## Cosa ti serve prima di iniziare

- Un PC Windows (lo script è stato sviluppato e testato lì, ma funziona con piccoli adattamenti anche su Linux/macOS)
- **Python** versione 3.10 o successiva installato
- **Nmap** installato — è un programma gratuito e open source; su Windows, il suo installer include già il driver "Npcap" necessario per fare le scansioni di rete
- Un account Telegram (quasi certamente ce l'hai già)

## Guida all'installazione, passo per passo

### Passo 1 — Installa le librerie Python necessarie

Apri il terminale (Prompt dei comandi su Windows) nella cartella del progetto e scrivi:
```bash
pip install -r requirements.txt
```
Questo comando installa automaticamente `python-nmap` (per parlare con Nmap da Python) e `requests` (per comunicare con Telegram).

### Passo 2 — Crea il tuo bot Telegram personale

Ogni bot Telegram ha bisogno di un "token", una specie di password segreta che lo identifica. Per ottenerlo:

1. Apri l'app Telegram e cerca l'utente **@BotFather** (è il bot ufficiale di Telegram per creare altri bot)
2. Scrivigli il comando `/newbot`
3. Ti chiederà un **nome** per il bot (può essere qualsiasi cosa, es. "Il mio WiFi Monitor") e poi uno **username**, che deve essere univoco e finire per "bot" (es. `MioWifiMonitor_bot`)
4. Se tutto va a buon fine, BotFather ti risponderà con un messaggio che contiene il tuo **TOKEN**, una stringa simile a questa:
   ```
   123456789:AAHdqTcvCH1vGWJxfSeofSAs0K5PALDsaw
   ```
   Copialo e tienilo da parte, ti servirà tra poco. **Non condividerlo mai con nessuno**: chi lo possiede può controllare il bot al posto tuo.

### Passo 3 — Trova il tuo Chat ID

Il bot deve sapere **a chi** mandare i messaggi: per questo serve il tuo "Chat ID", un numero che identifica la tua chat personale con lui.

1. Cerca il bot che hai appena creato (usando lo username che gli hai dato) e aprigli una chat
2. Scrivigli un messaggio qualsiasi, ad esempio "ciao"
3. Apri il browser e incolla questo indirizzo, sostituendo `<TOKEN>` con il token ottenuto al passo precedente:
   ```
   https://api.telegram.org/bot<TOKEN>/getUpdates
   ```
4. Nella pagina che si apre vedrai un testo con diverse informazioni. Cerca la parte che assomiglia a:
   ```
   "chat":{"id":987654321,"first_name":"Mario",...}
   ```
   Il numero accanto a `"id"` (nell'esempio `987654321`) è il tuo **Chat ID**.

Se la pagina mostra `"result":[]` (vuoto), significa che il messaggio non è ancora arrivato: scrivi di nuovo al bot e ricarica la pagina.

### Passo 4 — Trova la tua rete e il tuo router

Apri il Prompt dei comandi di Windows e scrivi:
```
ipconfig
```
Cerca la sezione relativa alla tua connessione Wi-Fi e annota due valori:
- **Indirizzo IPv4** (es. `192.168.1.15`): ti serve per capire la tua subnet, che sarà quasi sempre la stessa sequenza con `.0/24` alla fine (quindi `192.168.1.0/24`)
- **Gateway predefinito** (es. `192.168.1.1`): è l'indirizzo della pagina di amministrazione del tuo router

### Passo 5 — Configura lo script con i tuoi dati

Apri il file `wifi_monitor_bot.py` con un editor di testo qualsiasi (va benissimo anche il Blocco Note di Windows) e trova questo blocco all'inizio del file:

```python
TELEGRAM_BOT_TOKEN = ""   # token ottenuto da @BotFather
TELEGRAM_CHAT_ID = ""     # il tuo chat_id personale
NETWORK_RANGE = "192.168.1.0/24"   # la tua subnet
SCAN_INTERVAL_SECONDS = 60         # ogni quanto scansionare
NMAP_PATH = r"C:\Program Files (x86)\Nmap\nmap.exe"   # percorso di nmap.exe
ROUTER_URL = "http://192.168.1.1"  # indirizzo del tuo router
```

Sostituisci i valori tra virgolette con i tuoi dati reali, uno per uno:
- `TELEGRAM_BOT_TOKEN`: il token del Passo 2
- `TELEGRAM_CHAT_ID`: il numero del Passo 3 (scrivilo comunque tra virgolette, come testo, anche se è composto solo da cifre)
- `NETWORK_RANGE`: la tua subnet del Passo 4
- `NMAP_PATH`: dove hai installato Nmap — se lo hai installato con le impostazioni di default su Windows, questo percorso va bene così com'è; in caso contrario, cerca dove si trova `nmap.exe` sul tuo PC
- `ROUTER_URL`: il gateway trovato al Passo 4, preceduto da `http://`

Salva il file.

### Passo 6 — Avvia il bot

Dal terminale, nella cartella dello script:
```bash
python wifi_monitor_bot.py
```

Se hai dimenticato di inserire token o chat_id, lo script te lo segnala subito a schermo e si ferma, senza fare nient'altro. Se invece è tutto a posto, entro un minuto dovresti iniziare a ricevere i primi messaggi con i dispositivi trovati sulla rete.

## Avvio automatico all'accensione del PC (Windows)

Se vuoi che il bot parta da solo ogni volta che accendi il computer, senza doverlo lanciare a mano:

1. Apri l'**Utilità di pianificazione** di Windows (cercala nel menu Start)
2. Clicca **"Crea attività..."** (non quella "di base")
3. Nella scheda **Generale**: dai un nome all'attività e spunta **"Esegui con i privilegi più elevati"** — è fondamentale, perché la scansione ARP di Nmap richiede permessi da amministratore su Windows
4. Nella scheda **Attivazione**: crea un nuovo trigger con "Inizia l'attività" impostato su **"All'avvio del computer"**
5. Nella scheda **Azioni**: crea una nuova azione che avvii `python.exe` (trovi il percorso esatto scrivendo `where python` da cmd), con `wifi_monitor_bot.py` come argomento, e la cartella dello script come percorso di partenza
6. Nella scheda **Condizioni**: togli la spunta da "Avvia l'attività solo se il computer è collegato alla rete elettrica"
7. Salva

## Problemi comuni

- **Non arriva nessun messaggio**: controlla il file di log `wifi_monitor_log.txt`, che viene creato automaticamente nella stessa cartella dello script e registra ogni passaggio (scansione avviata, dispositivi trovati, eventuali errori)
- **Lo script resta bloccato senza fare nulla**: quasi sempre è un problema di percorso di Nmap non trovato — verifica che `NMAP_PATH` punti esattamente al file `nmap.exe` sul tuo PC
- **Funziona da terminale ma non quando parte da solo all'avvio**: assicurati di aver spuntato "Esegui con i privilegi più elevati" nell'Utilità di pianificazione

## ⚠️ Attenzione alla sicurezza prima di pubblicare il codice

Una volta configurato, questo script contiene il **token del bot scritto in chiaro** all'interno del file `.py`. Il token è a tutti gli effetti una password: chiunque lo ottenga può controllare il tuo bot, leggere i messaggi e mandarne a tuo nome.

**Se mantieni questo progetto su un repository pubblico (es. GitHub):**
- Non fare mai il commit del file `wifi_monitor_bot.py` **dopo** aver inserito i tuoi dati reali
- Mantieni online solo la versione con i placeholder vuoti (`TELEGRAM_BOT_TOKEN = ""`), come quella originale di questo repository
- Le tue modifiche personali con i dati reali vanno fatte solo in una copia locale del file, che non va mai committata
- Se per errore un token finisce comunque online, revocalo subito parlando con @BotFather (comando `/revoke`) e generane uno nuovo

## Licenza

Questo progetto è distribuito liberamente per uso personale ed educativo.
