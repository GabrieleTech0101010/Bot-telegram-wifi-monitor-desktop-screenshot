"""
WiFi Device Monitor Bot (versione Nmap)
-----------------------------------------
Scansiona la rete locale periodicamente usando Nmap e invia una notifica
Telegram ogni volta che compare un dispositivo (MAC address) mai visto prima.

Vedi README.md per le istruzioni complete di installazione e configurazione.
"""

import json
import logging
import os
import time
from datetime import datetime

import nmap
import requests

# ==================== CONFIGURAZIONE ====================
# Inserisci qui i tuoi valori prima di avviare lo script.
# Vedi il README.md per sapere come ottenerli.
TELEGRAM_BOT_TOKEN = ""   # token ottenuto da @BotFather
TELEGRAM_CHAT_ID = ""     # il tuo chat_id personale
NETWORK_RANGE = "192.168.1.0/24"   # la tua subnet locale
SCAN_INTERVAL_SECONDS = 60         # ogni quanto scansionare
NMAP_PATH = r"C:\Program Files (x86)\Nmap\nmap.exe"   # percorso di nmap.exe (Windows)
ROUTER_URL = "http://192.168.1.1"  # indirizzo della pagina di amministrazione del router
KNOWN_DEVICES_FILE = os.path.join(os.path.dirname(os.path.abspath(__file__)), "known_devices.json")
# ==========================================================

LOG_FILE = os.path.join(os.path.dirname(os.path.abspath(__file__)), "wifi_monitor_log.txt")
logging.basicConfig(
    filename=LOG_FILE,
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(message)s",
)
log = logging.getLogger(__name__)

scanner = nmap.PortScanner(nmap_search_path=(NMAP_PATH,))


def get_device_emoji(vendor):
    """Ritorna un'emoji in base al nome del produttore del dispositivo."""
    if not vendor or vendor == "Sconosciuto":
        return "❓"
    vendor_lower = vendor.lower()
    if "apple" in vendor_lower:
        return "🍎"
    if "samsung" in vendor_lower:
        return "📱"
    if any(x in vendor_lower for x in ["tp-link", "netgear", "d-link", "asus", "linksys"]):
        return "📡"
    if any(x in vendor_lower for x in ["amazon", "google", "sonos"]):
        return "🔊"
    if any(x in vendor_lower for x in ["hp", "canon", "epson", "brother"]):
        return "🖨️"
    if any(x in vendor_lower for x in ["dell", "lenovo", "microsoft", "intel", "asustek"]):
        return "💻"
    return "🔌"


def send_telegram_message(text):
    url = f"https://api.telegram.org/bot{TELEGRAM_BOT_TOKEN}/sendMessage"
    keyboard = {
        "inline_keyboard": [[
            {"text": "🌐 Apri pagina router", "url": ROUTER_URL}
        ]]
    }
    payload = {
        "chat_id": TELEGRAM_CHAT_ID,
        "text": text,
        "parse_mode": "HTML",
        "reply_markup": json.dumps(keyboard),
    }
    try:
        resp = requests.post(url, data=payload, timeout=10)
        log.info(f"Messaggio Telegram inviato, risposta: {resp.status_code}")
    except requests.RequestException as e:
        log.error(f"Errore invio Telegram: {e}", exc_info=True)


def load_known_devices():
    if os.path.exists(KNOWN_DEVICES_FILE):
        with open(KNOWN_DEVICES_FILE, "r") as f:
            return json.load(f)
    return {}


def save_known_devices(devices):
    with open(KNOWN_DEVICES_FILE, "w") as f:
        json.dump(devices, f, indent=2)


def scan_network(ip_range):
    """Fa una scansione 'ping scan + ARP' (-sn) e ritorna {ip, mac, hostname, vendor}."""
    scanner.scan(hosts=ip_range, arguments="-sn")
    devices = []
    for host in scanner.all_hosts():
        info = scanner[host]
        mac = info["addresses"].get("mac", "SCONOSCIUTO")
        hostname = info.hostname() or "Sconosciuto"
        vendor = info.get("vendor", {}).get(mac, "Sconosciuto")
        devices.append({"ip": host, "mac": mac, "hostname": hostname, "vendor": vendor})
    return devices


def main():
    if not TELEGRAM_BOT_TOKEN or not TELEGRAM_CHAT_ID:
        print("[!] ERRORE: devi prima inserire TELEGRAM_BOT_TOKEN e TELEGRAM_CHAT_ID")
        print("    nelle prime righe di questo file. Vedi il README.md per le istruzioni.")
        return

    log.info(f"Avvio monitoraggio rete {NETWORK_RANGE} ogni {SCAN_INTERVAL_SECONDS}s (Nmap)")
    known_devices = load_known_devices()

    while True:
        try:
            log.info("Inizio scansione rete...")
            found = scan_network(NETWORK_RANGE)
            log.info(f"Scansione completata: {len(found)} dispositivi trovati")
            for device in found:
                mac = device["mac"]
                ip = device["ip"]
                if mac == "SCONOSCIUTO":
                    continue

                if mac not in known_devices:
                    now = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
                    known_devices[mac] = {
                        "first_seen": now,
                        "last_ip": ip,
                        "hostname": device["hostname"],
                        "vendor": device["vendor"],
                    }
                    save_known_devices(known_devices)

                    emoji = get_device_emoji(device["vendor"])
                    msg = (
                        f"{emoji} <b>Nuovo dispositivo sulla rete!</b>\n\n"
                        f"<b>IP:</b> <code>{ip}</code>\n"
                        f"<b>MAC:</b> <code>{mac}</code>\n"
                        f"<b>Hostname:</b> {device['hostname']}\n"
                        f"<b>Produttore:</b> {device['vendor']}\n"
                        f"<b>Rilevato il:</b> {now}"
                    )
                    log.info(f"Nuovo dispositivo trovato: {ip} / {mac}")
                    send_telegram_message(msg)
                else:
                    if known_devices[mac]["last_ip"] != ip:
                        known_devices[mac]["last_ip"] = ip
                        save_known_devices(known_devices)

        except Exception as e:
            log.error(f"Errore durante la scansione: {e}", exc_info=True)

        time.sleep(SCAN_INTERVAL_SECONDS)


if __name__ == "__main__":
    main()
