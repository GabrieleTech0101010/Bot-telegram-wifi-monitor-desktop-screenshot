"""
PC Screenshot Bot
-------------------
Bot Telegram che, quando riceve il comando /screenshot, cattura lo schermo
del PC e lo rimanda indietro come foto nella chat.

Vedi README.md per le istruzioni complete di installazione e configurazione.
"""

import io
import logging
import os
import time

import pyautogui
import requests

# ==================== CONFIGURAZIONE ====================
# Inserisci qui i tuoi valori prima di avviare lo script.
# Vedi il README.md per sapere come ottenerli.
TELEGRAM_BOT_TOKEN = ""     # token ottenuto da @BotFather
AUTHORIZED_CHAT_ID = ""     # solo questo chat_id può usare i comandi
POLL_INTERVAL_SECONDS = 2
# ==========================================================

LOG_FILE = os.path.join(os.path.dirname(os.path.abspath(__file__)), "screenshot_bot_log.txt")
logging.basicConfig(
    filename=LOG_FILE,
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(message)s",
)
log = logging.getLogger(__name__)

API_URL = f"https://api.telegram.org/bot{TELEGRAM_BOT_TOKEN}"


def take_screenshot_bytes():
    screenshot = pyautogui.screenshot()
    buffer = io.BytesIO()
    screenshot.save(buffer, format="PNG")
    buffer.seek(0)
    return buffer


def send_screenshot(chat_id):
    try:
        image_bytes = take_screenshot_bytes()
        files = {"photo": ("screenshot.png", image_bytes, "image/png")}
        data = {"chat_id": chat_id, "caption": "📸 Screenshot del PC"}
        resp = requests.post(f"{API_URL}/sendPhoto", data=data, files=files, timeout=30)
        log.info(f"Screenshot inviato, risposta: {resp.status_code}")
    except Exception as e:
        log.error(f"Errore durante l'invio dello screenshot: {e}", exc_info=True)


def send_text(chat_id, text):
    try:
        requests.post(f"{API_URL}/sendMessage", data={"chat_id": chat_id, "text": text}, timeout=10)
    except Exception as e:
        log.error(f"Errore invio messaggio: {e}", exc_info=True)


def get_updates(offset):
    try:
        resp = requests.get(
            f"{API_URL}/getUpdates",
            params={"offset": offset, "timeout": 20},
            timeout=25,
        )
        return resp.json().get("result", [])
    except Exception as e:
        log.error(f"Errore durante getUpdates: {e}", exc_info=True)
        return []


def main():
    if not TELEGRAM_BOT_TOKEN or not AUTHORIZED_CHAT_ID:
        print("[!] ERRORE: devi prima inserire TELEGRAM_BOT_TOKEN e AUTHORIZED_CHAT_ID")
        print("    nelle prime righe di questo file. Vedi il README.md per le istruzioni.")
        return

    log.info("Avvio PC Screenshot Bot, in ascolto di comandi...")
    offset = 0

    while True:
        updates = get_updates(offset)

        for update in updates:
            offset = update["update_id"] + 1
            message = update.get("message", {})
            chat_id = str(message.get("chat", {}).get("id", ""))
            text = message.get("text", "").strip().lower()

            if chat_id != AUTHORIZED_CHAT_ID:
                log.info(f"Messaggio ignorato da chat_id non autorizzato: {chat_id}")
                continue

            if text == "/screenshot":
                log.info("Comando /screenshot ricevuto, cattura in corso...")
                send_screenshot(chat_id)
            elif text == "/start":
                send_text(chat_id, "Ciao! Scrivi /screenshot per ricevere una foto dello schermo del PC.")

        time.sleep(POLL_INTERVAL_SECONDS)


if __name__ == "__main__":
    main()
