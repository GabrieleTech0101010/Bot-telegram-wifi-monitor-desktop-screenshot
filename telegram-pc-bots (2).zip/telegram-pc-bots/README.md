<p align="center">
  <img src="https://readme-typing-svg.demolab.com?font=Fira+Code&size=28&pause=1000&color=00C9A7&center=true&vCenter=true&width=600&lines=Telegram+PC+Bots;Monitora+il+tuo+PC+da+remoto;Scritto+in+Python+%F0%9F%90%8D" alt="Typing SVG" />
</p>

<p align="center">
  <img src="https://img.shields.io/badge/Author-Gabriele%20Tech-brightgreen?style=for-the-badge" alt="Author" />
  <img src="https://img.shields.io/badge/Platform-Windows-blue?style=for-the-badge" alt="Platform" />
  <img src="https://img.shields.io/badge/Status-Active-brightgreen?style=for-the-badge" alt="Status" />
</p>

# 🤖 Telegram PC Bots

## Cosa trovi in questo repository

Questo progetto raccoglie due piccoli programmi Python (li chiamiamo "bot", perché comunicano tramite l'app Telegram) pensati per chi vuole tenere d'occhio o controllare il proprio PC anche quando non è seduto davanti allo schermo.

**Non serve essere programmatori esperti per usarli**: questa pagina ti guida passo passo, spiegando anche i concetti tecnici in modo semplice. Se segui le istruzioni nell'ordine, in 10-15 minuti avrai il tuo bot funzionante.

| Bot | A cosa serve, in parole semplici |
|---|---|
| 📡 [`wifi-monitor-bot`](./wifi-monitor-bot) | Ti manda un messaggio su Telegram ogni volta che un dispositivo nuovo (un telefono, un PC, qualsiasi cosa) si collega alla tua rete WiFi di casa |
| 📸 [`screenshot-bot`](./screenshot-bot) | Scrivi un comando dal telefono e ricevi subito una foto di cosa sta mostrando lo schermo del tuo PC in quel momento |

Ogni bot ha la propria cartella con un file **README.md** dedicato, che spiega nel dettaglio come funziona e come configurarlo — clicca sui link della tabella qui sopra per aprirli.

## Perché un "bot Telegram" e non un'altra app?

Telegram mette a disposizione gratuitamente un sistema (chiamato "API") che permette a un programma di mandare e ricevere messaggi come se fosse una persona. Questo è comodo perché:
- Non devi installare nessuna app aggiuntiva: usi Telegram, che probabilmente hai già sul telefono
- Puoi ricevere notifiche ovunque tu sia, basta avere internet
- È completamente gratuito, sia per te che per chi scrive il programma

## Cosa ti serve prima di iniziare

- Un PC Windows acceso (i bot devono girare su un computer che resta acceso per poterli usare)
- **Python** installato (è il linguaggio di programmazione con cui sono scritti i bot) — se non sai se ce l'hai, apri il Prompt dei comandi e scrivi `python --version`; se non lo riconosce, scaricalo gratis da [python.org](https://www.python.org/downloads/)
- Un account Telegram, anche quello che usi normalmente

## Come iniziare

1. Scegli quale bot ti interessa di più (puoi installarli entrambi, sono completamente indipendenti)
2. Apri la cartella corrispondente e segui il suo README.md, che contiene tutte le istruzioni dettagliate
3. In entrambi i casi dovrai creare un "bot Telegram" tramite l'assistente ufficiale **@BotFather** — il procedimento è identico ed è spiegato in ogni README

## ⚠️ Nota sulla sicurezza

Ogni bot ha bisogno di un "token", una specie di password segreta che Telegram ti dà quando crei il bot. Questo token va inserito direttamente dentro al file Python di ciascun bot (trovi le istruzioni precise in ogni README).

**Importantissimo**: una volta inserito il tuo token reale, quel file diventa "personale" e non va mai ricondiviso o ripubblicato online così com'è — altrimenti chiunque potrebbe controllare il tuo bot al posto tuo. I file di questo repository, così come li trovi qui, contengono solo spazi vuoti al posto del token, proprio per essere sicuri da pubblicare.

## 📄 Licenza

Questo progetto è distribuito sotto **licenza MIT**, una delle licenze open source più permissive e diffuse. In parole semplici, significa che:
- Chiunque può usare, copiare, modificare e ridistribuire questo codice liberamente, anche per scopi commerciali
- L'unica condizione è mantenere il testo della licenza originale (il file [`LICENSE`](./LICENSE)) nelle copie o versioni derivate
- Il codice viene fornito "così com'è", senza garanzie: l'autore non è responsabile di eventuali problemi derivanti dal suo utilizzo

Per il testo legale completo, consulta il file [`LICENSE`](./LICENSE) in questo repository.
